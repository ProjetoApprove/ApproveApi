<?php
session_start();

if (isset($_POST['login']) && !empty($_POST['email']) && !empty($_POST['password'])) {
    
    include_once('connect.php');
    $email = $_POST['email'];
    $password = $_POST['password'];

 
    $sql = "SELECT * FROM usuarios WHERE email = '$email' AND password = '$password'";   
    $result = $conexao->query($sql);

    if (mysqli_num_rows($result) < 1) {
     
        unset($_SESSION['email']);
        unset($_SESSION['password']);
        unset($_SESSION['username']);
        unset($_SESSION['id']);
        header('Location: login.php');
    } else {
        
        $user = $result->fetch_assoc();
        
      
        $_SESSION['email'] = $user['email'];
        $_SESSION['password'] = $user['password'];
        $_SESSION['username'] = $user['username']; 
        $_SESSION['id'] = $user['id'];  

   
        header('Location: ../funcoes/home.php');
    }
} else {
    
    header('location: login.php');
}
?>
