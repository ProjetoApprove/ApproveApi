<?php

$dbHost = 'localhost';
$dbUsername = 'u301136860_user';
$dbPassword = 'Ovictoregay123!';
$dbName = 'u301136860_approve';

$conexao = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

//if($conexao->connect_errno)
//{
//    echo "Erro";
//}
//else
//{
//    echo 'Conexão efetuada com sucesso';
//}

?>